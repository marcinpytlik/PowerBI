---
name: Bug report
about: Zgłoś błąd w raporcie/modelu
---

## Opis
-

## Kroki odtworzenia
1.
2.
3.

## Oczekiwany wynik
-

## Rzeczywisty wynik
-

## Środowisko
- Power BI Desktop wersja:
- Branch/commit:
