---
name: Feature request
about: Propozycja zmiany/funkcji
---

## Co chcesz dodać/zmienić?
-

## Po co?
-

## Kryteria akceptacji
- [ ]
- [ ]
