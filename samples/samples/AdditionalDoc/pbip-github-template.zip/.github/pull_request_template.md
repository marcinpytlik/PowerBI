## Co zmieniamy?
-

## Dlaczego?
-

## Zakres
- [ ] Model (TMDL): tabele / relacje / DAX / RLS
- [ ] Report (PBIR): strony / visuale / formatowanie
- [ ] Data (PQ): query / transformacje / parametry

## Checklist
- [ ] Power BI Desktop otwiera projekt bez błędów
- [ ] Odświeżenie danych działa (albo jest świadomie pominięte z opisem)
- [ ] Zmiany opisane w `docs/CHANGELOG.md`
- [ ] Zaktualizowane `docs/MODEL_NOTES.md` (jeśli dotyczy)
- [ ] Screenshoty istotnych zmian (jeśli UI/raport): `docs/screens/`

## Notatki do review
- Potencjalne ryzyka:
- Wpływ na wydajność:
