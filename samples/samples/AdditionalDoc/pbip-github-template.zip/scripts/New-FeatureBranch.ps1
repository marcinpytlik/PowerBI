[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)]
  [string]$Name
)

$ErrorActionPreference = "Stop"

$branch = "feature/$Name".Replace(" ", "-").ToLowerInvariant()
git checkout -b $branch
Write-Host "Switched to $branch" -ForegroundColor Green
