[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

Write-Host "== Repo health check ==" -ForegroundColor Cyan

$bad = @()
$patterns = @("cache.abf","localSettings.json",".pbi")
foreach ($p in $patterns) {
  $found = Get-ChildItem -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.FullName -like "*$p*" }
  foreach ($f in $found) { $bad += $f.FullName }
}

if ($bad.Count -gt 0) {
  Write-Host "Znaleziono pliki, które zwykle nie powinny trafić do repo:" -ForegroundColor Yellow
  $bad | Sort-Object -Unique | ForEach-Object { Write-Host " - $_" }
  Write-Host "Usuń je z repo i dodaj do .gitignore (jeśli trzeba)." -ForegroundColor Yellow
  exit 2
}

Write-Host "OK: nie znaleziono typowych cache/local plików." -ForegroundColor Green
