[CmdletBinding()]
param(
  [switch]$NoGlobalGitConfig
)

$ErrorActionPreference = "Stop"

Write-Host "== PBIP repo init ==" -ForegroundColor Cyan

if (-not $NoGlobalGitConfig) {
  Write-Host "Setting global git defaults for Windows (core.autocrlf=true, core.safecrlf=warn)"
  git config --global core.autocrlf true | Out-Null
  git config --global core.safecrlf warn | Out-Null
} else {
  Write-Host "Skipping global git config (NoGlobalGitConfig)"
}

Write-Host "Ensuring repository is initialized..."
if (-not (Test-Path ".git")) {
  git init | Out-Null
  git branch -M main | Out-Null
}

Write-Host "Creating folders..."
New-Item -ItemType Directory -Force -Path "src","docs","docs\screens","scripts" | Out-Null

Write-Host "Done. Next steps:" -ForegroundColor Green
Write-Host "1) Skopiuj wygenerowane przez Power BI foldery *.Report / *.SemanticModel oraz plik .pbip do ./src/"
Write-Host "2) git add . && git commit -m "Init PBIP project""
Write-Host "3) git remote add origin <url> && git push -u origin main"
