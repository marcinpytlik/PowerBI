# Contributing

## Zasady
1. Pracujemy na branchach (`feature/*`, `hotfix/*`).
2. Wszystko idzie przez Pull Request.
3. PR ma opis + checklistę (template).
4. Nie commitujemy cache (`.pbi/`, `cache.abf`, `localSettings.json`).

## Jak przygotować zmianę
1. `git checkout -b feature/<nazwa>`
2. Zmień raport/model w Power BI Desktop.
3. `git add .`
4. `git commit -m "Opis"`
5. `git push -u origin feature/<nazwa>`
6. Otwórz PR na GitHubie.
