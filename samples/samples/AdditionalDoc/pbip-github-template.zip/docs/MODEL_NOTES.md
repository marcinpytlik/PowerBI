# Notatki do modelu (TMDL / DAX / relacje)

## Parametry / źródła danych
- Źródło: (opisz, bez sekretów)
- Parametry: (nazwy, wartości domyślne, gdzie zmienić)

## Tabele (krótko)
- FactSales: ...
- DimDate: ...
- DimCustomer: ...

## Miary (DAX)
- [Sales Net] = ...
- [Margin %] = ...

## Relacje
- DimDate[Date] 1-* FactSales[OrderDate]
- DimCustomer[CustomerKey] 1-* FactSales[CustomerKey]

## RLS
- Role: RegionalManagers – zasady, kolumny, testy
