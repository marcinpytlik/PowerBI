# Changelog

Format: YYYY-MM-DD – krótki opis

## Unreleased
-

