# Workflow zespołowy PBIP (Power BI)

Ten dokument opisuje „jak pracujemy”, żeby repo nie zamieniło się w pole minowe.

## 1) Branching

- `main` – stabilna wersja
- `feature/<krótki-opis>` – nowe funkcje/zmiany
- `hotfix/<krótki-opis>` – szybkie poprawki

**Reguła:** wszystko idzie przez PR (Pull Request).

## 2) Commit messages (prosto i czytelnie)

Przykłady:
- `Add measures: Sales Net, Margin %`
- `Fix relationship Customer->Sales`
- `Rework page: Executive Overview layout`
- `Update RLS role: RegionalManagers`

Dopisz 1–2 zdania w opisie commita/PR:
- *co* zmieniono,
- *dlaczego*,
- *jaki wpływ* (wydajność, wyniki, strony raportu).

## 3) Podział pracy (minimalizacja konfliktów)

Najlepiej działa:
- Osoba A: model (PQ, relacje, DAX, RLS)
- Osoba B: raport (layout, strony, visuale)

Unikajcie równoległej edycji tej samej strony raportu.

## 4) Checklist PR

Zobacz `.github/pull_request_template.md` – PR bez checklisty = PR bez duszy.

## 5) Konflikty merge

Jeśli konflikt dotyczy plików raportu:
- Najpierw spróbuj rozwiązać standardowo (merge w VS Code).
- Jeśli to „kocioł w JSON-ach” – często szybciej:
  1) jedna osoba resetuje swoją wersję strony,
  2) ręcznie odtwarza zmiany w Power BI Desktop,
  3) commit „clean”.

## 6) Odświeżanie danych

Repo nie przechowuje sekretów.
- Connection strings / credentials: tylko przez Service / Gateway / parametry lokalne.
- W `docs/MODEL_NOTES.md` opisuj parametry i źródła danych (bez haseł).

