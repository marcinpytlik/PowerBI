# Power BI (PBIP) – repo zespołowe (szablon)

Ten repozytorium jest przygotowane do pracy zespołowej nad **Power BI Project (.pbip)**:
- raport w formacie **PBIR** (enhanced metadata),
- model w formacie **TMDL** (tekstowe pliki – sensowny diff/merge).

## Szybki start (Windows + VS Code + GitHub)

1. **Skonwertuj PBIX → PBIP**
   - Power BI Desktop → `File` → `Save as` → **Power BI project files (*.pbip)**.
   - Zapisz projekt w krótkiej ścieżce, np. `C:\src\pbi\MyReport\`.

2. **Wgraj wygenerowane foldery do repo**
   W katalogu repo umieść (skopiuj) foldery utworzone przez Power BI:
   - `./src/<Nazwa>.Report/`
   - `./src/<Nazwa>.SemanticModel/`
   - `./src/<Nazwa>.pbip` (plik projektu)

3. **Zainicjalizuj repo i ustaw zasady**
   W PowerShell (w katalogu repo):
   ```powershell
   ./scripts/Init-Repo.ps1
   ```

4. **Pracuj w branchach + PR**
   ```powershell
   git checkout -b feature/nazwa-zmiany
   # zmiany w PBI Desktop
   git add .
   git commit -m "Opis zmian"
   git push -u origin feature/nazwa-zmiany
   ```
   Potem robisz Pull Request na GitHubie.

## Co jest w repo

- `src/` – tu trzymasz właściwy projekt PBIP (foldery *.Report / *.SemanticModel + plik .pbip)
- `docs/` – dokumentacja: zasady pracy, changelog, notatki do modelu
- `scripts/` – gotowe skrypty PowerShell (Windows)
- `.vscode/` – ustawienia VS Code + rekomendowane rozszerzenia
- `.github/` – szablony PR/Issue (żeby review miało sens)

## Zasady współpracy (skrót)

- **Nie commitujemy cache** (`.pbi/`, `cache.abf`, `localSettings.json`) – repo ma być lekkie i deterministyczne.
- **Nie edytujemy ręcznie** losowych plików raportu „na czuja”. Zmieniamy rzeczy w Power BI Desktop.
  Ręczna edycja ma sens głównie dla TMDL (model) – i tylko świadomie.
- Staramy się **nie dłubać w tej samej stronie raportu w tym samym czasie** (mniej konfliktów).

## FAQ

**Czy da się robić diff jak w kodzie?**  
Tak – dla TMDL i PBIR w dużej mierze tak. Dla PBIX: praktycznie nie.

**Czy PBIP zastępuje deployment do Power BI Service?**  
Nie – to format projektu do wersjonowania. Publikowanie do Service to osobny etap (manualnie lub pipeline’em).

---

Autor szablonu: marcin + Duduś 😄
